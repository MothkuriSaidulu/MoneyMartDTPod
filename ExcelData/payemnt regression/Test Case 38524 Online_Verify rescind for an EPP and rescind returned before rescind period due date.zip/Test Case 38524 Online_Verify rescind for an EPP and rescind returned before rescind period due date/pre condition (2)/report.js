$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Online_MM/features/CAN_Online_TC05_EPP_approved.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "##scneario:: Test case 60285: TS_06_Online_New_Customer_EPP_Approved_EFT funding_Rescind \u0026 return Rescind transaction"
    }
  ],
  "line": 2,
  "name": "Online_New Customer_EPP_Approved",
  "description": "",
  "id": "online-new-customer-epp-approved",
  "keyword": "Feature"
});
formatter.before({
  "duration": 3659048400,
  "status": "passed"
});
formatter.scenario({
  "line": 5,
  "name": "Online_New Customer_EPP_Approved|TC_05_EPP_Loan",
  "description": "",
  "id": "online-new-customer-epp-approved;online-new-customer-epp-approved|tc-05-epp-loan",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@EPPApproved"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "Genareted sin",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user click on signup customer",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Pre-requisite data generation for customer",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "verify the phonenumber threshold",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "Verify the address threshold and update address",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Create customer",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "Run the TU query",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "customer chooses SPL loan",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "User provides basic information for spl",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Provides income information",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "signed the picra and submit application",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "enter valid OTP",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 19,
      "value": "#And select the funding types"
    }
  ],
  "line": 20,
  "name": "add the bank details",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "upload document",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "verify the loan status and update loan status in DB",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "User opens the chrome and launch online application",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "User login online Application",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "click on Finalize and e-Sign Loan Documents",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "Loan approved final offer",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "funding and payment confirmation EPP",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "esing document and back to dashboard",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "verify the DB validatioin",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "verify the dasboard and rescind loan",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "verify the DB validatioin for rescind",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 33,
      "value": "## Return rescind payment from storm"
    },
    {
      "line": 34,
      "value": "###log file"
    }
  ],
  "line": 35,
  "name": "Initialize Loan Details and write to excel",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "log all the Loan details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "log all the Note details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "log all payment details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "log all Transaction details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 40,
  "name": "log all EFTLog details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "log all ETransferLog details in logger for investigation",
  "keyword": "And "
});
formatter.match({
  "location": "random_generate.genareted_sin()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.embedding("image/png", "embedded1.png");
formatter.result({
  "duration": 23336716100,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.user_click_on_signup_customer()"
});
formatter.embedding("image/png", "embedded2.png");
formatter.embedding("image/png", "embedded3.png");
formatter.embedding("image/png", "embedded4.png");
formatter.result({
  "duration": 20125581800,
  "status": "passed"
});
formatter.match({
  "location": "random_generate.create_customerpre_requisite_data_generation()"
});
formatter.result({
  "duration": 4284125900,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.verify_the_phonenumber_threshold()"
});
formatter.result({
  "duration": 10334260500,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.verify_the_address_threshold_and_update_address()"
});
formatter.result({
  "duration": 21454195500,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.create_customer()"
});
formatter.embedding("image/png", "embedded5.png");
formatter.embedding("image/png", "embedded6.png");
formatter.embedding("image/png", "embedded7.png");
formatter.result({
  "duration": 27466524500,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.run_the_TU_query()"
});
formatter.result({
  "duration": 8465658600,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.customer_chooses_SPL_loan()"
});
formatter.embedding("image/png", "embedded8.png");
formatter.result({
  "duration": 5823795700,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.user_provides_basic_information_for_spl()"
});
formatter.embedding("image/png", "embedded9.png");
formatter.result({
  "duration": 38057257600,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.provides_income_information()"
});
formatter.embedding("image/png", "embedded10.png");
formatter.embedding("image/png", "embedded11.png");
formatter.embedding("image/png", "embedded12.png");
formatter.embedding("image/png", "embedded13.png");
formatter.result({
  "duration": 27636069100,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.signed_the_picra_and_submit_application()"
});
formatter.embedding("image/png", "embedded14.png");
formatter.embedding("image/png", "embedded15.png");
formatter.result({
  "duration": 20042212400,
  "status": "passed"
});
formatter.match({
  "location": "TC37_autovoid_esignpending.enter_valid_OTP()"
});
formatter.embedding("image/png", "embedded16.png");
formatter.embedding("image/png", "embedded17.png");
formatter.result({
  "duration": 93029186800,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.add_the_bank_details()"
});
formatter.embedding("image/png", "embedded18.png");
formatter.result({
  "duration": 9553884800,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.upload_document()"
});
formatter.embedding("image/png", "embedded19.png");
formatter.embedding("image/png", "embedded20.png");
formatter.result({
  "duration": 15666131200,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_status_and_update_loan_status_in_DB()"
});
formatter.result({
  "duration": 4321260700,
  "status": "passed"
});
formatter.match({
  "location": "Reloan_refi_changes.user_opens_the_chrome_and_launch_online_application()"
});
formatter.result({
  "duration": 3641908600,
  "status": "passed"
});
formatter.match({
  "location": "Reloan_refi_changes.user_login_online_Application()"
});
formatter.embedding("image/png", "embedded21.png");
formatter.result({
  "duration": 15510162000,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.click_on_Finalize_and_e_Sign_Loan_Documents()"
});
formatter.embedding("image/png", "embedded22.png");
formatter.embedding("image/png", "embedded23.png");
formatter.embedding("image/png", "embedded24.png");
formatter.result({
  "duration": 19688304700,
  "status": "passed"
});
formatter.match({
  "location": "TC23_EPP_Cross_Sell.loan_approved_final_offer()"
});
formatter.embedding("image/png", "embedded25.png");
formatter.result({
  "duration": 11906691100,
  "status": "passed"
});
formatter.match({
  "location": "TC06_EPP_approved.funding_and_payment_confirmation_EPP()"
});
formatter.embedding("image/png", "embedded26.png");
formatter.result({
  "duration": 12650323000,
  "status": "passed"
});
formatter.match({
  "location": "TC23_EPP_Cross_Sell.esing_document_and_back_to_dashboard()"
});
formatter.embedding("image/png", "embedded27.png");
formatter.result({
  "duration": 25098945500,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.verify_the_DB_validatioin()"
});
formatter.result({
  "duration": 9446906900,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_dasboard_and_rescind_loan()"
});
formatter.embedding("image/png", "embedded28.png");
formatter.embedding("image/png", "embedded29.png");
formatter.embedding("image/png", "embedded30.png");
formatter.embedding("image/png", "embedded31.png");
formatter.result({
  "duration": 9467847200,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_DB_validatioin_for_rescind()"
});
formatter.result({
  "duration": 11414036300,
  "status": "passed"
});
formatter.match({
  "location": "schedulerandDBlog.Initialize_Loan_Details_and_write_to_excel()"
});
formatter.result({
  "duration": 3247782400,
  "status": "passed"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Loan_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "duration": 1084121400,
  "status": "passed"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Note_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "duration": 1153528800,
  "status": "passed"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_payment_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "duration": 1084871500,
  "status": "passed"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_Transaction_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "duration": 1098379400,
  "status": "passed"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_EFTLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "duration": 1166735400,
  "status": "passed"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_ETransferLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "duration": 1107786800,
  "status": "passed"
});
formatter.after({
  "duration": 4344992200,
  "status": "passed"
});
formatter.uri("C:/Online_MM/features/CAN_Online_TC28_IL_LPP_refund.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "##Scenario:: Test case 97431: TC01_Verify LPP Refund"
    }
  ],
  "line": 3,
  "name": "Online_IL_autofund_LPP_Refund",
  "description": "",
  "id": "online-il-autofund-lpp-refund",
  "keyword": "Feature"
});
formatter.before({
  "duration": 5191100,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Online_IL_autofund_LPP_Refund|TC_28_IL_LPP_Refund",
  "description": "",
  "id": "online-il-autofund-lpp-refund;online-il-autofund-lpp-refund|tc-28-il-lpp-refund",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@ILApproved"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Genareted sin",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user click on signup",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "Pre-requisite data generation for customer",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "verify the email threshold",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Enter all details and create account",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "verify the phonenumber threshold",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 13,
      "value": "# And Verify the address threshold and update address"
    }
  ],
  "line": 14,
  "name": "Run the TU query",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "customer chooses IL loan",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "User provides basic information",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "select the flink consent",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "Provides income information",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "signed the picra and submit application",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "verify the funding screen and chosses the funding type",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "add the bank details",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "upload document",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "verify the loan status and update loan status in DB",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "click on Finalize and e-Sign Loan Documents",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "Verify the loan approved amount",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "chosses the either LPP yes or no",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "bank details",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "Verify the loan documents",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "verify the DB validatioin",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 31,
      "value": "###log file"
    }
  ],
  "line": 32,
  "name": "Initialize Loan Details and write to excel",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "log all the Loan details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "log all the Note details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "log all payment details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "log all Transaction details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "log all EFTLog details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "log all ETransferLog details in logger for investigation",
  "keyword": "And "
});
formatter.match({
  "location": "random_generate.genareted_sin()"
});
formatter.embedding("image/png", "embedded32.png");
formatter.result({
  "duration": 6434242900,
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: unhandled inspector error: {\"code\":-32000,\"message\":\"Not attached to an active page\"}\n  (Session info: chrome\u003d107.0.5304.122)\nBuild info: version: \u00273.5.3\u0027, revision: \u0027a88d25fe6b\u0027, time: \u00272017-08-29T12:42:44.417Z\u0027\nSystem info: host: \u0027QAVDIWIN10-39\u0027, ip: \u002710.220.111.95\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_321\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d106.0.5249.61 (511755355844955cd3e264779baf0dd38212a4d0-refs/branch-heads/5249@{#569}), userDataDir\u003dC:\\Users\\91434\\AppData\\Local\\Temp\\scoped_dir18364_909782563}, timeouts\u003d{implicit\u003d0, pageLoad\u003d300000, script\u003d30000}, pageLoadStrategy\u003dnone, unhandledPromptBehavior\u003ddismiss and notify, strictFileInteractability\u003dfalse, platform\u003dXP, proxy\u003dProxy(), goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:54069}, webauthn:extension:credBlob\u003dtrue, acceptInsecureCerts\u003dfalse, browserVersion\u003d107.0.5304.122, browserName\u003dchrome, javascriptEnabled\u003dtrue, platformName\u003dXP, setWindowRect\u003dtrue, webauthn:extension:largeBlob\u003dtrue, webauthn:virtualAuthenticators\u003dtrue}]\nSession ID: 9c9bc23788d07e393ffb770eacbacf86\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:185)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:120)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:82)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:646)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:703)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.getScreenshotAs(RemoteWebDriver.java:388)\r\n\tat online.StepDefinitions.hooks.takeScreenshotimage(hooks.java:41)\r\n\tat online.StepDefinitions.hooks.bindreport(hooks.java:211)\r\n\tat online.StepDefinitions.random_generate.genareted_sin(random_generate.java:29)\r\n\tat ✽.Given Genareted sin(C:/Online_MM/features/CAN_Online_TC28_IL_LPP_refund.feature:7)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "ILLoandenied.user_click_on_signup()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "random_generate.create_customerpre_requisite_data_generation()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.verify_the_email_threshold()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.Enter_all_details_and_create_account()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.verify_the_phonenumber_threshold()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.run_the_TU_query()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.customer_chooses_IL_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.user_provides_basic_information()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.select_the_flink_consent()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.provides_income_information()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.signed_the_picra_and_submit_application()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_funding_screen_and_chosses_the_funding_type()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.add_the_bank_details()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.upload_document()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_status_and_update_loan_status_in_DB()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.click_on_Finalize_and_e_Sign_Loan_Documents()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_approved_amount()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.chosses_the_either_LPP_yes_or_no()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.veirfy_the_funding_types_and_bank_details()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_documents()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.verify_the_DB_validatioin()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.Initialize_Loan_Details_and_write_to_excel()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Loan_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Note_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_payment_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_Transaction_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_EFTLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_ETransferLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 149610900,
  "error_message": "org.openqa.selenium.WebDriverException: unknown error: unhandled inspector error: {\"code\":-32000,\"message\":\"Not attached to an active page\"}\n  (Session info: chrome\u003d107.0.5304.122)\nBuild info: version: \u00273.5.3\u0027, revision: \u0027a88d25fe6b\u0027, time: \u00272017-08-29T12:42:44.417Z\u0027\nSystem info: host: \u0027QAVDIWIN10-39\u0027, ip: \u002710.220.111.95\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_321\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d106.0.5249.61 (511755355844955cd3e264779baf0dd38212a4d0-refs/branch-heads/5249@{#569}), userDataDir\u003dC:\\Users\\91434\\AppData\\Local\\Temp\\scoped_dir18364_909782563}, timeouts\u003d{implicit\u003d0, pageLoad\u003d300000, script\u003d30000}, pageLoadStrategy\u003dnone, unhandledPromptBehavior\u003ddismiss and notify, strictFileInteractability\u003dfalse, platform\u003dXP, proxy\u003dProxy(), goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:54069}, webauthn:extension:credBlob\u003dtrue, acceptInsecureCerts\u003dfalse, browserVersion\u003d107.0.5304.122, browserName\u003dchrome, javascriptEnabled\u003dtrue, platformName\u003dXP, setWindowRect\u003dtrue, webauthn:extension:largeBlob\u003dtrue, webauthn:virtualAuthenticators\u003dtrue}]\nSession ID: 9c9bc23788d07e393ffb770eacbacf86\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:185)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:120)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:82)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:646)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:703)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.getScreenshotAs(RemoteWebDriver.java:388)\r\n\tat online.StepDefinitions.hooks.afterScenario(hooks.java:151)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat java.lang.reflect.Method.invoke(Method.java:498)\r\n\tat cucumber.runtime.Utils$1.call(Utils.java:40)\r\n\tat cucumber.runtime.Timeout.timeout(Timeout.java:16)\r\n\tat cucumber.runtime.Utils.invoke(Utils.java:34)\r\n\tat cucumber.runtime.java.JavaHookDefinition.execute(JavaHookDefinition.java:60)\r\n\tat cucumber.runtime.Runtime.runHookIfTagsMatch(Runtime.java:224)\r\n\tat cucumber.runtime.Runtime.runHooks(Runtime.java:212)\r\n\tat cucumber.runtime.Runtime.runAfterHooks(Runtime.java:206)\r\n\tat cucumber.runtime.model.CucumberScenario.run(CucumberScenario.java:46)\r\n\tat cucumber.runtime.junit.ExecutionUnitRunner.run(ExecutionUnitRunner.java:102)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:63)\r\n\tat cucumber.runtime.junit.FeatureRunner.runChild(FeatureRunner.java:18)\r\n\tat org.junit.runners.ParentRunner$4.run(ParentRunner.java:331)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:79)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:329)\r\n\tat org.junit.runners.ParentRunner.access$100(ParentRunner.java:66)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:293)\r\n\tat org.junit.runners.ParentRunner$3.evaluate(ParentRunner.java:306)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:413)\r\n\tat cucumber.runtime.junit.FeatureRunner.run(FeatureRunner.java:70)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:95)\r\n\tat cucumber.api.junit.Cucumber.runChild(Cucumber.java:38)\r\n\tat org.junit.runners.ParentRunner$4.run(ParentRunner.java:331)\r\n\tat org.junit.runners.ParentRunner$1.schedule(ParentRunner.java:79)\r\n\tat org.junit.runners.ParentRunner.runChildren(ParentRunner.java:329)\r\n\tat org.junit.runners.ParentRunner.access$100(ParentRunner.java:66)\r\n\tat org.junit.runners.ParentRunner$2.evaluate(ParentRunner.java:293)\r\n\tat org.junit.internal.runners.statements.RunAfters.evaluate(RunAfters.java:27)\r\n\tat org.junit.runners.ParentRunner$3.evaluate(ParentRunner.java:306)\r\n\tat org.junit.runners.ParentRunner.run(ParentRunner.java:413)\r\n\tat cucumber.api.junit.Cucumber.run(Cucumber.java:100)\r\n\tat driver.CustomRunner.run(CustomRunner.java:23)\r\n\tat org.eclipse.jdt.internal.junit4.runner.JUnit4TestReference.run(JUnit4TestReference.java:93)\r\n\tat org.eclipse.jdt.internal.junit.runner.TestExecution.run(TestExecution.java:40)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:529)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.runTests(RemoteTestRunner.java:756)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.run(RemoteTestRunner.java:452)\r\n\tat org.eclipse.jdt.internal.junit.runner.RemoteTestRunner.main(RemoteTestRunner.java:210)\r\n",
  "status": "failed"
});
});