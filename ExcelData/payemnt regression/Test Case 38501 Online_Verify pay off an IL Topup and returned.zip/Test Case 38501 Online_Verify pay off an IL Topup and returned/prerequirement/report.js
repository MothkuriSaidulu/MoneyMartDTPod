$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Online_MM/features/CAN_Online_TC28_IL_LPP_refund.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "##Scenario:: Test case 97431: TC01_Verify LPP Refund"
    }
  ],
  "line": 3,
  "name": "Online_IL_autofund_LPP_Refund",
  "description": "",
  "id": "online-il-autofund-lpp-refund",
  "keyword": "Feature"
});
formatter.before({
  "duration": 5221254300,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Online_IL_autofund_LPP_Refund|TC_28_IL_LPP_Refund",
  "description": "",
  "id": "online-il-autofund-lpp-refund;online-il-autofund-lpp-refund|tc-28-il-lpp-refund",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@ILApproved"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Genareted sin",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user click on signup",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "Pre-requisite data generation for customer",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "verify the email threshold",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "Enter all details and create account",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "verify the phonenumber threshold",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 13,
      "value": "# And Verify the address threshold and update address"
    }
  ],
  "line": 14,
  "name": "Run the TU query",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "customer chooses IL loan",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "User provides basic information",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "select the flink consent",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "Provides income information",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "signed the picra and submit application",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "verify the funding screen and chosses the funding type",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "add the bank details",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "upload document",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "verify the loan status and update loan status in DB",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "click on Finalize and e-Sign Loan Documents",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "Verify the loan approved amount",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "chosses the either LPP yes or no",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "bank details",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "Verify the loan documents",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "verify the DB validatioin",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 31,
      "value": "###log file"
    }
  ],
  "line": 32,
  "name": "Initialize Loan Details and write to excel",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "log all the Loan details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "log all the Note details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "log all payment details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "log all Transaction details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "log all EFTLog details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "log all ETransferLog details in logger for investigation",
  "keyword": "And "
});
formatter.match({
  "location": "random_generate.genareted_sin()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.embedding("image/png", "embedded1.png");
formatter.result({
  "duration": 33501819500,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.user_click_on_signup()"
});
formatter.embedding("image/png", "embedded2.png");
formatter.embedding("image/png", "embedded3.png");
formatter.embedding("image/png", "embedded4.png");
formatter.result({
  "duration": 23482243500,
  "status": "passed"
});
formatter.match({
  "location": "random_generate.create_customerpre_requisite_data_generation()"
});
formatter.result({
  "duration": 13081446400,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.verify_the_email_threshold()"
});
formatter.result({
  "duration": 6463813000,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.Enter_all_details_and_create_account()"
});
formatter.embedding("image/png", "embedded5.png");
formatter.embedding("image/png", "embedded6.png");
formatter.embedding("image/png", "embedded7.png");
formatter.embedding("image/png", "embedded8.png");
formatter.result({
  "duration": 30919608700,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.verify_the_phonenumber_threshold()"
});
formatter.result({
  "duration": 8312693400,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.run_the_TU_query()"
});
formatter.result({
  "duration": 8470062000,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.customer_chooses_IL_loan()"
});
formatter.embedding("image/png", "embedded9.png");
formatter.result({
  "duration": 15739232900,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.user_provides_basic_information()"
});
formatter.embedding("image/png", "embedded10.png");
formatter.embedding("image/png", "embedded11.png");
formatter.embedding("image/png", "embedded12.png");
formatter.result({
  "duration": 40255743400,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.select_the_flink_consent()"
});
formatter.embedding("image/png", "embedded13.png");
formatter.result({
  "duration": 5870258200,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.provides_income_information()"
});
formatter.embedding("image/png", "embedded14.png");
formatter.embedding("image/png", "embedded15.png");
formatter.embedding("image/png", "embedded16.png");
formatter.embedding("image/png", "embedded17.png");
formatter.result({
  "duration": 27340915400,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.signed_the_picra_and_submit_application()"
});
formatter.embedding("image/png", "embedded18.png");
formatter.embedding("image/png", "embedded19.png");
formatter.result({
  "duration": 18687723600,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_funding_screen_and_chosses_the_funding_type()"
});
formatter.embedding("image/png", "embedded20.png");
formatter.embedding("image/png", "embedded21.png");
formatter.result({
  "duration": 121592063000,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.add_the_bank_details()"
});
formatter.embedding("image/png", "embedded22.png");
formatter.result({
  "duration": 10197574800,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.upload_document()"
});
formatter.embedding("image/png", "embedded23.png");
formatter.embedding("image/png", "embedded24.png");
formatter.result({
  "duration": 15617199000,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_status_and_update_loan_status_in_DB()"
});
formatter.result({
  "duration": 4236692900,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.click_on_Finalize_and_e_Sign_Loan_Documents()"
});
formatter.embedding("image/png", "embedded25.png");
formatter.embedding("image/png", "embedded26.png");
formatter.embedding("image/png", "embedded27.png");
formatter.result({
  "duration": 18808537100,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_approved_amount()"
});
formatter.embedding("image/png", "embedded28.png");
formatter.result({
  "duration": 14604560300,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.chosses_the_either_LPP_yes_or_no()"
});
formatter.embedding("image/png", "embedded29.png");
formatter.embedding("image/png", "embedded30.png");
formatter.result({
  "duration": 30898705900,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.veirfy_the_funding_types_and_bank_details()"
});
formatter.embedding("image/png", "embedded31.png");
formatter.result({
  "duration": 7914844000,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_documents()"
});
formatter.result({
  "duration": 10770642200,
  "error_message": "java.lang.AssertionError: WebDriverException : WHILE TRYING TO CLICK ON THE SPECIFIED WEB ELEMENTUser_unable_to_click_on_the_\u003cb\u003echeckbox for Loan Agreement\u003c/b\u003e_due_to_the_Exception:-element click intercepted: Element \u003cspan class\u003d\"mm-checkbox__box\"\u003e\u003c/span\u003e is not clickable at point (818, 26). Other element would receive the click: \u003cdiv class\u003d\"mm-header__right\"\u003e...\u003c/div\u003e\n  (Session info: chrome\u003d107.0.5304.122)\nBuild info: version: \u00273.5.3\u0027, revision: \u0027a88d25fe6b\u0027, time: \u00272017-08-29T12:42:44.417Z\u0027\nSystem info: host: \u0027QAVDIWIN10-39\u0027, ip: \u002710.220.111.95\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_321\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d106.0.5249.61 (511755355844955cd3e264779baf0dd38212a4d0-refs/branch-heads/5249@{#569}), userDataDir\u003dC:\\Users\\91434\\AppData\\Local\\Temp\\scoped_dir13292_710821026}, timeouts\u003d{implicit\u003d0, pageLoad\u003d300000, script\u003d30000}, pageLoadStrategy\u003dnone, unhandledPromptBehavior\u003ddismiss and notify, strictFileInteractability\u003dfalse, platform\u003dXP, proxy\u003dProxy(), goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:60208}, webauthn:extension:credBlob\u003dtrue, acceptInsecureCerts\u003dfalse, browserVersion\u003d107.0.5304.122, browserName\u003dchrome, javascriptEnabled\u003dtrue, platformName\u003dXP, setWindowRect\u003dtrue, webauthn:extension:largeBlob\u003dtrue, webauthn:virtualAuthenticators\u003dtrue}]\nSession ID: 8f5c71ad682333c2243ebb674d069835\r\n\tat org.testng.Assert.fail(Assert.java:97)\r\n\tat actions.OnlineActions.click(OnlineActions.java:321)\r\n\tat pages.Pg_11_eSignDocs.Sign_Loan_Docs(Pg_11_eSignDocs.java:265)\r\n\tat online.StepDefinitions.TC01_ILLoanApproved_Review.verify_the_loan_documents(TC01_ILLoanApproved_Review.java:98)\r\n\tat ✽.And Verify the loan documents(C:/Online_MM/features/CAN_Online_TC28_IL_LPP_refund.feature:28)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "ILLoandenied.verify_the_DB_validatioin()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.Initialize_Loan_Details_and_write_to_excel()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Loan_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Note_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_payment_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_Transaction_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_EFTLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_ETransferLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded32.png");
formatter.after({
  "duration": 1092502500,
  "status": "passed"
});
});